def getRatesHandle():
    print("GET RATES TOUCH")
    