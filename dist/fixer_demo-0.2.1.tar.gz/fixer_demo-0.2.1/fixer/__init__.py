from fixer.handler import getRatesHandle

__all__ = ["getRatesHandle"]