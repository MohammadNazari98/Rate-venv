from setuptools import setup

setup(name="fixer-demo",
      version='0.2',
      description="Fixer service demo package",
      url="#",
      author="Mohammad",
      author_email="Mohammad@gmail.com",
      license="MIT",
      packages=['fixer'],
      install_require=["requests"],
      zip_safe=False)